<?php

//Define your host here.
$HostName = "localhost";

//Define your database username here.
$HostUser = "id12764400_logindb";

//Define your database password here.
$HostPass = "logindb";

//Define your database name here.
$DatabaseName = "id12764400_logindb";

?>