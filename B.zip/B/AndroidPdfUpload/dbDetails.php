define('DB_HOST','localhost');
define('DB_USERNAME','id12764400_logindb');
define('DB_PASSWORD','logindb');
define('DB_NAME','id12764400_logindb');



