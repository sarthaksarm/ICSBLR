db_config.php
<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "id12764400_logindb"); // db user
define('DB_PASSWORD', "logindb"); // db password (mention your db password here)
define('DB_DATABASE', "id12764400_logindb"); // database name
define('DB_SERVER', "localhost"); // db server
?>
